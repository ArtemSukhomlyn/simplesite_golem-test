

browsers = [
    'chrome-headless'
]

environments = []

workers = 1

tests = [
    '*'
]
