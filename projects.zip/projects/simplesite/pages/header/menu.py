

CS = ('xpath', '//*[@id=\"2017_customerservice\"]', 'CS')

Features = ('xpath', '//*[@id=\"2017_features\"]', 'Features')

Make = ('xpath', '//*[@id=\"2017_startwizard\"]', 'Make')

Theam = ('xpath', '//*[@id=\"2017_themes\"]', 'Theam')

Login_button = ('id', '_ctl0_Header2017_btnLogin', 'Login_button')